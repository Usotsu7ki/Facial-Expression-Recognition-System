#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // 创建一个QPalette对象
   QPalette palette;

   // 加载背景图片
   QPixmap backgroundImage(":/res/pic/login.jpg");

   // 缩放背景图片以适应MainWindow的大小
   backgroundImage = backgroundImage.scaled(size(), Qt::IgnoreAspectRatio);

   // 将背景图片设置为QPalette的背景
   palette.setBrush(QPalette::Background, backgroundImage);

   // 将QPalette应用到MainWindow中
   setPalette(palette);
}

MainWindow::~MainWindow()
{
    delete ui;
}

